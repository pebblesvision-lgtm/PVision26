# pvsketch: production drawing from a photo (module for embedding)

**What it is.** A browser-only web app for Pebbles Vision (natural stone restoration). A photo of a
stone element (raamdorpel, dorpel, ornament, …) becomes a clean **outline** (lines and arcs). On it
the user registers **measurements they measured by hand**, marks **hand-tooled finishes**
(frijnen, kathedraalslag, randslag, …) and exports **PDF, PNG/JPEG, DXF (R12), SVG, CSV, JSON**.
Nothing is measured from the photo: the first typed measurement sets the drawing's scale. Until
then every export says **NIET OP SCHAAL**.

Dutch UI by default, English via ⚙. Built for iPad on scaffolding: everything on one screen, big
buttons, pinch zoom. It works offline after the first visit.

**No server, no build step, no framework.** It's plain static files. All processing (OpenCV.js
GrabCut, contour fitting and the exporters) runs in a Web Worker, and projects are stored in
the browser's **IndexedDB** on that device.

## Workflow (6 steps, top bar)

| Step | What the user does |
|---|---|
| 1 Foto | Take or choose a photo, open the sample, or open a project (.json backup) |
| 2 Isoleren | Tap **Punten** around the stone, drag a **Kader**, or paint with **Steen +**, then **Uitvoeren**. After a run, **Steen +** and **Gum** edit the yellow area directly (undoable). *Overslaan* skips straight to measuring on the photo |
| 3 Omtrek | Outline extraction with arc fitting. Tools: Bekijken / Verplaatsen / Punt toevoegen / Punt verwijderen (they work on arcs too) |
| 4 Opmeten | Tap 2 points, type the measured value. Schuin (along the line) / Horizontaal (width only) / Verticaal (height only) / Tekst / Selecteren (restyle or delete a line). Measurement list: Vrij (default), Standaard (lengte, breedte, diepte) or an element template. *+ Maat* adds a custom measurement. *Maatlijnen ordenen* lays out the lines neatly |
| 5 Tekenen | Finish areas with hatching (strokes per 10 cm and a comment, both shown in the legend), lines, arrows and text. *Selecteren* changes an existing area or line afterwards |
| 6 Exporteren | Title block, extra views (side view or profile from another project) on the same sheet, all exports |

## Files

```
pvsketch/
  index.html            page (UI markup)
  app.js, app.css       UI (vanilla JS)
  shim.js               intercepts fetch("/api/...") and download links, answers them from the worker
  worker.js             Web Worker: loads vendor/opencv.js + engine/*.js
  engine/*.js           the pipeline (segment, contour, geometry, hatch, exports, IndexedDB store, router api.js)
  vendor/opencv.js      OpenCV.js 5.0.0 (13 MB, cached after first load)
  sw.js                 service worker (offline cache)
  manifest.webmanifest, icon-192.png, icon-512.png   PWA install
  sample.jpg            sample photo
  _headers              Cloudflare Pages cache headers (optional elsewhere)
  version.txt
```

## How to include it in another web app

All asset paths are **relative**, so the folder can be served from any sub-path, for example
`https://myapp.example/pvsketch/`. Copy the folder into the host app's static/public directory unchanged.

1. **Link or new tab (simplest):** `<a href="/pvsketch/">Tekening maken</a>`.
2. **iframe:** `<iframe src="/pvsketch/" style="width:100%;height:100vh;border:0" allow="camera"></iframe>`.
   For the camera button to work in an iframe, the iframe must be same-origin (or allow camera)
   and the page must be served over HTTPS.
3. **Do not** merge `index.html`/`app.js` into another page's DOM. The UI uses global element IDs,
   and `shim.js` replaces `window.fetch` for every path starting with `/api/`. That would break the
   host app's own `/api/` calls. Keep it on its own page or in an iframe.

Hosting requirements: HTTPS (or localhost) for the service worker and camera, and Web Worker and WASM
support (every modern browser, including iPad Safari). `.js` files must be served as JavaScript.
There is no server-side code.

### Data exchange with the host app

Projects live in IndexedDB on the device, under the origin that serves pvsketch. A host app on the
**same origin** (same domain) can reach the data in two ways:
- From the pvsketch page/iframe, call the internal API through `fetch` (inside that page only):
  - `GET /api/projects`: list of projects
  - `GET /api/projects/<id>`: full state (dimensions, finishes, checklist, title block, …)
  - `GET /api/projects/<id>/drawing`: drawing in mm (outline, dimensions, finishes with hatching, bbox)
  - `GET /api/projects/<id>/export.{pdf|png|jpg|dxf|svg|csv|json}?lang=nl|en&photo=1&paper=a4|a3`
  - `POST /api/projects/import` with `{text: <contents of a .pvsketch.json>}`
- Exchange files: **Exporteren → JSON** gives a self-contained `.pvsketch.json` (photo, mask, outline,
  measurements, finishes). The host app can store that file, and pvsketch re-opens it with *Project openen (.json)*.
  The **CSV** export holds the measurements table (number, label, kind, value in mm).

`.pvsketch.json` format: `{format:"pvsketch-project", version:1, state:{…}, original_mime, original_b64, mask_b64}`.
Useful `state` fields: `name`, `titleblock{project,element,material,quantity,finish,drawn_by,notes}`,
`dimensions[{p1,p2,kind,manual_mm,label,style,offset_mm}]` (mm, y down), `checklist[{key,nl,en,kind,value_mm,dim_id}]`,
`finishes[{polygon,kind,strokes_per_10cm,angle_deg,width_mm,comment}]`, `calibration{ppm,scaled,scale_note}`, `template`.

There is no postMessage API yet. If the host app needs one (for example "send the finished
measurements to my quote screen"), that's a small addition to `app.js`. Ask for it.

## Limits

- One face per photo. Side views are separate projects, linked in step 6.
- The outline is the shape as the camera saw it, so photograph square-on. Typed measurements always take priority.
- Data stays on the device (back it up via the JSON export). Safari can clear data for sites you don't use, and installing to the home screen mostly prevents that.

Source and Python/server version: GitHub `pebblesvision-lgtm/PVision26`, branch `claude/beautiful-gauss-0i92a6`
(`web/engine` = engine source, `tools/build_cloudflare.py` rebuilds this folder).
